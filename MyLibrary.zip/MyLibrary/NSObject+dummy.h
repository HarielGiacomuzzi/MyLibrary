//
//  NSObject+dummy.h
//  MyLibrary
//
//  Created by Rafael on 6/5/15.
//  Copyright (c) 2015 Hariel Giacomuzzi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (dummy)

@end
